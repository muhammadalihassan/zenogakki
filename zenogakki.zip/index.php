<?php $navitem = "home"; include 'include/head.php'; ?>


<!-- background stuff -->


<div class="magic"></div>
       <audio id="webbgaudios" loop >
       <source src="https://d1z8nn7yvmka87.cloudfront.net/musicx.mp3"  type="audio/mp3">
     </audio>
      <video class="deks-view desktop-view" muted="" playsinline="" loop="" autoplay="" webkit-playsinline="" id="third-video">
         <source src="https://d1z8nn7yvmka87.cloudfront.net/desktop.mp4" type="video/mp4">
      </video>
       <video class="deks-view mobile-view" muted="" playsinline="" loop="" autoplay="" webkit-playsinline="" id="third-video">
         <source src="https://d1z8nn7yvmka87.cloudfront.net/Mobile.mp4" type="video/mp4">
      </video>

<div class="intro-video counter">
       <img src="images/ver-logo.png" alt="logo">
       <p>0%</p>
</div>


<!-- background stuff -->
<span class="index-body">
   <?php include 'include/header.php'; ?>
   <?php index("home") ?>
</span>

            <div class="index-banner-txt">
              <div class="container" id="data-append">
                <!-- <div ></div>
                <div class="main-heading"><h1 class="drop-in">THE REBIRTH OF MANKIND</h1></div>
                <a href="utopia.php" class="drop-in-2">ENTER UTOPIA <i class="fa-solid fa-angles-right"></i></a> -->
              </div>
            </div>
          </div>
            
         </div>
      </div>
<?php include 'include/footer.php'; ?>
