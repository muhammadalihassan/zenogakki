<?php $navitem = "utopia"; include 'include/head.php'; ?>


<!-- background stuff -->


<!-- <div class="magic"></div> -->
       <audio id="webbgaudios" loop >
       <source src="https://zenogakki.io/images/utopia.mp3"  type="audio/mp3">
     </audio>
     <img class="deks-view" id="third-video" src="images/utopia.png" alt="zenogakki">
<!-- background stuff -->

<span class="utopia-bg">
<?php include 'include/header.php'; ?>
<?php others("utopia") ?>
</span>
            <div class="utopia-txt btm-line">
               <div class="row">
                  <div class="col-md-12 col-lg-12 col-xl-3 no-pad">
                     <div class="story-txt">
                        <h6>UTOPIA</h6>
                        <h4> STORY <span>LINE</span></h4>
                     </div>
                  </div>
                  <div class="col-md-12 col-lg-12 col-xl-9 no-pad">
                     <div class="story-line">
                      <div class="scroll-mob">
                        <p>A deadly virus was released into Utopia by an unknown entity, a virus that was powerful enough to eradicate humanity.
                        However, there are small traces of humanity left within Utopia and these remaining humans have taken upon themselves to be responsible for seeking retribution. Artificial Intelligence has taken over Utopia. This was the birth of a new cyber species, The Zeils, that was created by an all-powerful and merciless AI.
                        His name was Karth, The Cyber Ruler.
                        </p>
                      </div>
                     </div>
                  </div>
               </div>
            </div>
          </div>
            
         </div>
      </div>
<?php include 'include/footer.php'; ?>
