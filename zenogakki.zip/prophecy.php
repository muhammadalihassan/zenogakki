<?php $navitem = "prophecy"; include 'include/head.php'; ?>


<!-- background stuff -->


       <audio id="webbgaudios" loop >
       <source src="https://zenogakki.io/images/phosphery-music.mp3"  type="audio/mp3">
     </audio>
<!--      <img class="deks-view" id="third-video" src="images/prophecy.png" alt="zenogakki">
 --> <video class="deks-view" muted="" playsinline="" loop="" autoplay="" webkit-playsinline="" id="third-video">
         <source src="images/Karth.mp4" type="video/mp4">
      </video>


<!-- background stuff -->

<span class="pro-bg">
<?php include 'include/header.php'; ?>
<?php others("prophecy") ?>
</span>

            <div class="utopia-txt btm-line">
               <div class="row">
                  <div class="col-md-12 col-lg-12 col-xl-4 no-pad">
                     <div class="story-txt">
                        <h6>PROPHECY</h6>
                        <h4> WHITEPAPER</h4>
                        <a href="images/Project-Zenogakki-Whitepaper.pdf" download><i class="fa-solid fa-download"></i> DOWNLOAD</a>
                     </div>
                  </div>
                  <div class="col-md-12 col-lg-12 col-xl-8 no-pad">
                     <div class="story-line prophecy-line">
                      <div class="scroll-mob">
                        <!-- <button onclick="typeWriter()">Click me</button> -->
                        <p id="demo"></p>
                      </div>
                       
                     </div>
                  </div>
               </div>
            </div>
          </div>
            
         </div>
      </div>
<?php include 'include/footer.php'; ?>
